package weka.classifiers.meta;

/*
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *   
 *   This is research code, not production code.
 *
 */

/*
 *    ULTRABOOST.java
 *
 */

import java.util.ArrayList;

import java.util.Random;

import weka.classifiers.Classifier;

import weka.classifiers.RandomizableMultipleClassifiersCombiner;

import weka.core.*;
//import weka.classifiers.evaluation.Evaluation;

import weka.core.TechnicalInformation.Field;
import weka.core.TechnicalInformation.Type;

/**
 <!-- globalinfo-start -->
 * UltraBoost adaptively boosts heterogenous classifiers.<br/>
 * <br/>
 * For more information, see<br/>
 * <br/>
 * Venkatesh, S. S., Levenback, B. J., Sultan, L. R., Bouzghar, G., & Sehgal, C. M. (2015). 
 * Going beyond a first reader: A machine learning methodology for optimizing cost and performance in breast ultrasound diagnosis. 
 * Ultrasound in medicine & biology, 41(12), 3148-3162.
 * <p/>
 <!-- globalinfo-end -->
 *
 <!-- technical-bibtex-start -->
 * BibTeX:
 * <pre>
 *
 * &#article{venkatesh2015going,
 * 	title={Going beyond a first reader: A machine learning methodology for optimizing cost and performance in breast ultrasound diagnosis},
 * 	author={Venkatesh, Santosh S and Levenback, Benjamin J and Sultan, Laith R and Bouzghar, Ghizlane and Sehgal, Chandra M},
 * 	journal={Ultrasound in medicine \& biology},
 * 	volume={41},
 * 	number={12},
 * 	pages={3148--3162},
 * 	year={2015},
 * 	publisher={Elsevier}
 * }
 * </pre>
 * <p/>
 <!-- technical-bibtex-end -->
 *
 * <!-- options-start --> Valid options are:
 * <p/>
 * 
 * <pre>
 *  -M &lt;scheme specification&gt;
 *  Full name of meta classifier, followed by options.
 *  (default: "weka.classifiers.rules.Zero")
 * </pre>
 * 
 * <pre>
 *  -X &lt;number of folds&gt;
 *  Sets the number of cross-validation folds.
 * </pre>
 * 
 * <pre>
 *  -S &lt;num&gt;
 *  Random number seed.
 *  (default 1)
 * </pre>
 * 
 * <pre>
 *  -B &lt;classifier specification&gt;
 *  Full class name of classifier to include, followed
 *  by scheme options. May be specified multiple times.
 *  (default: "weka.classifiers.rules.ZeroR")
 * </pre>
 * 
 * <pre>
 *  -D
 *  If set, classifier is run in debug mode and
 *  may output additional info to the console
 * </pre>
 * 
 * <!-- options-end -->
 *
 * @author Ted Cary (ted.cary@pennmedicine.upenn.edu)
 * @version $Revision: 121219 $
 */
public class UltraBoost extends RandomizableMultipleClassifiersCombiner implements TechnicalInformationHandler {

	/** for serialization */
	static final long serialVersionUID = 1212197208062019L; // 5134738557155845452L;

//  /** The meta classifier */
//  protected Classifier m_MetaClassifier = new ZeroR();
//
	// protected Classifier m_SpoofClassifier = new
	// weka.classifiers.functions.Logistic();

	protected ArrayList<Double> m_WeightsClassifiers = new ArrayList<Double>();

//  /** Format for meta data */
//  protected Instances m_MetaFormat = null;

//  /** Format for base data */
//  protected Instances m_BaseFormat = null;

//  /** Set the number of folds for the cross-validation */
//  protected int m_NumFolds = 10;

	public UltraBoost() throws Exception {

		FilteredClassifier Filter0 = new FilteredClassifier();
		FilteredClassifier Filter1 = new FilteredClassifier();

		// Classifier Filter1 = new weka.classifiers.functions.Logistic();

		// Filter0.setClassifier(new weka.classifiers.bayes.NaiveBayes());
		// Filter1.setClassifier(new weka.classifiers.functions.Logistic());

		String[] options0 = weka.core.Utils.splitOptions(
				"-F \"weka.filters.unsupervised.attribute.RemoveType -V -T nominal\" -S 1 -W weka.classifiers.bayes.NaiveBayes");

		Filter0.setOptions(options0);

		String[] options1 = weka.core.Utils.splitOptions(
				"-F \"weka.filters.unsupervised.attribute.RemoveType -V -T numeric\" -S 1 -W weka.classifiers.functions.Logistic");

		Filter1.setOptions(options1);

		// make sure constituent classifiers get passed the seed, if any
		// (you also could have used the -S switch in the args
		// to set the seed to m_Seed or anythin other than 1 above, 
		// then used SetOptions)
//		
		Filter0.setSeed(m_Seed); 
		Filter1.setSeed(m_Seed); 
//		
		Classifier[] Classifiers = { Filter0, Filter1 };

		this.m_Classifiers = Classifiers; // overwrites ZeroR that's set in super MultipleClassifiersCombiner

	}

	/**
	 * Returns a string describing classifier
	 * 
	 * @return a description suitable for displaying in the explorer/experimenter
	 *         gui
	 */
	public String globalInfo() {

		return "UltraBoost adaptively boosts (AdaBoosts) a series of heterogeneous classifiers."
				+ " Unlike canonical AdaBoost, base classifiers are not assumed to be weak -- they can be relatively strong, and dissimilar."
				+ " It is named UltraBoost because it was developed at the Ultrasound Research Lab at the University of Pennsylvania."
				+ "\n\n"
				+ "Tip: Each classifier can be passed a subsampling of features filtered to the classifier's natural attribute type."
				+ " This acts as a \"practitioner's regularization\" to reduce dimensionality."
				+ " For instance, naive Bayes naturally takes nominal attributes, whereas logistic regression takes numeric attributes."
				+ " In the default UltraBoost configuration, naive Bayes is the first classifier, regulated to only work on nominal types."
				+ " This is done by wrapping the base classifier with weka.classifiers.meta.FilteredClassifier with the RemoveType filter."
				+ " Study the default configuration to see how to regularize classifiers by filtering their natural type."
				+ "\n\n"
				+ "Prior to Weka 3.8.4, there was a bug in Weka's RemoveType filter when used with invertSelection."
				+ " This bug will throw the message: \"Problem evaluating classifier. Attribute names are not unique.\""
				+ " Though not as general, an easy workaround to the bug is to not use invertSelection in RemoveType filters."
				+ "\n\n"
				+ "In practice, often performance is best when the first classifier is the strongest, and only the first classifier is regularized by type."
				+ " Stringing together many heterogeneous strong classifiers may quickly overfit, and performance will decrease between boosts, depending on your problem."
				+ " The default naive Bayes then logistic regression sequence was purpose-built to work with ultrasound data from two different domains (image and clinician)."
				+ " A general strategy is to follow a strong regularized first classifier with \"sweeper\" boosted weak classifiers, like traditional AdaBoost or LogitBoost"
				+ "\n\n" + "Any base classifier that outputs probabilities can be boosted,"
				+ " however by default UltraBoost uses naive Bayes and logistic regression as described above and in the paper referenced below."
				+ "\n\n" + "For more information, see:" + "\n\n" + getTechnicalInformation().toString();
	}

	/**
	 * Returns an instance of a TechnicalInformation object, containing detailed
	 * information about the technical background of this class, e.g., paper
	 * reference or book this class is based on.
	 * 
	 * @return the technical information about this class
	 */
	public TechnicalInformation getTechnicalInformation() {
		TechnicalInformation result;

		result = new TechnicalInformation(Type.ARTICLE);
		result.setValue(Field.AUTHOR, "Santosh S. Venkatesh");
		result.setValue(Field.YEAR, "2015");
		result.setValue(Field.TITLE, "Going beyond a First Reader:"
				+ "A Machine Learning Methodology for Optimizing Cost and Performance in Breast Ultrasound Diagnosis.");
		result.setValue(Field.JOURNAL, "Ultrasound Med Bio");
		result.setValue(Field.VOLUME, "41");
		result.setValue(Field.PAGES, "3148-62");
		result.setValue(Field.PUBLISHER, "World Federation for Ultrasound in Medicine & Biology");

		return result;
	}

	/**
	 * Returns an enumeration describing the available options.
	 *
	 * @return an enumeration of all the available options.
	 */
//  public Enumeration<Option> listOptions() {

//    Vector<Option> newVector = new Vector<Option>(2);
//    newVector.addElement(new Option(
//	      metaOption(),
//	      "M", 0, "-M <scheme specification>"));
//    newVector.addElement(new Option(
//	      "\tSets the number of cross-validation folds.",
//	      "X", 1, "-X <number of folds>"));
//
//    newVector.addAll(Collections.list(super.listOptions()));
//    
//    if (getMetaClassifier() instanceof OptionHandler) {
//      newVector.addElement(new Option(
//        "",
//        "", 0, "\nOptions specific to meta classifier "
//          + getMetaClassifier().getClass().getName() + ":"));
//      newVector.addAll(Collections.list(((OptionHandler)getMetaClassifier()).listOptions()));
//    }
//    return newVector.elements();
//  }

	/**
	 * String describing option for setting meta classifier
	 * 
	 * @return the string describing the option
	 */
//  protected String metaOption() {
//
//    return "\tFull name of meta classifier, followed by options.\n" +
//      "\t(default: \"weka.classifiers.rules.Zero\")";
//  }

	/**
	 * Parses a given list of options.
	 * <p/>
	 *
	 * <!-- options-start --> Valid options are:
	 * <p/>
	 * 
	 * <pre>
	 *  -M &lt;scheme specification&gt;
	 *  Full name of meta classifier, followed by options.
	 *  (default: "weka.classifiers.rules.Zero")
	 * </pre>
	 * 
	 * <pre>
	 *  -X &lt;number of folds&gt;
	 *  Sets the number of cross-validation folds.
	 * </pre>
	 * 
	 * <pre>
	 *  -S &lt;num&gt;
	 *  Random number seed.
	 *  (default 1)
	 * </pre>
	 * 
	 * <pre>
	 *  -B &lt;classifier specification&gt;
	 *  Full class name of classifier to include, followed
	 *  by scheme options. May be specified multiple times.
	 *  (default: "weka.classifiers.rules.ZeroR")
	 * </pre>
	 * 
	 * <pre>
	 *  -D
	 *  If set, classifier is run in debug mode and
	 *  may output additional info to the console
	 * </pre>
	 * 
	 * <!-- options-end -->
	 *
	 * @param options the list of options as an array of strings
	 * @throws Exception if an option is not supported
	 */
//  public void setOptions(String[] options) throws Exception {
//
////    String numFoldsString = Utils.getOption('X', options);
////    if (numFoldsString.length() != 0) {
////      setNumFolds(Integer.parseInt(numFoldsString));
////    } else {
////      setNumFolds(10);
////    }
////    processMetaOptions(options);
////    super.setOptions(options);
//	  	  
//  }

	/**
	 * Process options setting meta classifier.
	 * 
	 * @param options the options to parse
	 * @throws Exception if the parsing fails
	 */
//  protected void processMetaOptions(String[] options) throws Exception {
//
//    String classifierString = Utils.getOption('M', options);
//    String [] classifierSpec = Utils.splitOptions(classifierString);
//    String classifierName;
//    if (classifierSpec.length == 0) {
//      classifierName = "weka.classifiers.rules.ZeroR";
//    } else {
//      classifierName = classifierSpec[0];
//      classifierSpec[0] = "";
//    }
//    setMetaClassifier(AbstractClassifier.forName(classifierName, classifierSpec));
//  }

	/**
	 * Gets the current settings of the Classifier.
	 *
	 * @return an array of strings suitable for passing to setOptions
	 */
//  public String [] getOptions() {
//
//    String [] superOptions = super.getOptions();
//    String [] options = new String [superOptions.length + 4];
//
//    int current = 0;
//    options[current++] = "-X"; options[current++] = "" + getNumFolds();
//    options[current++] = "-M";
//    options[current++] = getMetaClassifier().getClass().getName() + " "
//      + Utils.joinOptions(((OptionHandler)getMetaClassifier()).getOptions());
//
//    System.arraycopy(superOptions, 0, options, current, 
//		     superOptions.length);
//    return options;
//  }

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
//  public String numFoldsTipText() {
//    return "The number of folds used for cross-validation.";
//  }

	/**
	 * Gets the number of folds for the cross-validation.
	 *
	 * @return the number of folds for the cross-validation
	 */
//  public int getNumFolds() {
//
//    return m_NumFolds;
//  }

	/**
	 * Sets the number of folds for the cross-validation.
	 *
	 * @param numFolds the number of folds for the cross-validation
	 * @throws Exception if parameter illegal
	 */
//  public void setNumFolds(int numFolds) throws Exception {
//    
//    if (numFolds < 0) {
//      throw new IllegalArgumentException("Stacking: Number of cross-validation " +
//					 "folds must be positive.");
//    }
//    m_NumFolds = numFolds;
//  }

	/**
	 * Returns the tip text for this property
	 * 
	 * @return tip text for this property suitable for displaying in the
	 *         explorer/experimenter gui
	 */
//  public String metaClassifierTipText() {
//    return "The meta classifiers to be used.";
//  }

	/**
	 * Adds meta classifier
	 *
	 * @param classifier the classifier with all options set.
	 */
//  public void setMetaClassifier(Classifier classifier) {
//
//    m_MetaClassifier = classifier;
//  }

	/**
	 * Gets the meta classifier.
	 *
	 * @return the meta classifier
	 */
//  public Classifier getMetaClassifier() {
//    
//    return m_MetaClassifier;
//  }

	/**
	 * Returns combined capabilities of the base classifiers, i.e., the capabilities
	 * all of them have in common.
	 *
	 * @return the capabilities of the base classifiers
	 */
	public Capabilities getCapabilities() {
		Capabilities result;

		result = super.getCapabilities();
		// result.setMinimumNumberInstances(getNumFolds());
		result.setMinimumNumberInstances(10); // just arbitrarily say 10

		return result;
	}

	public double calculateMSE(Classifier classifier, Instances data) throws Exception {

		// this works for binary MSE
		// for nominal MSE, calculate the error per class and divide by number of
		// classes as well
		// see Evaluation.updateNumericScores for example

		double sumSqErr = 0.0d;

		for (Instance inst : data) {

			double actualClass = inst.classValue(); // should be 0 or 1
			double[] dist = classifier.distributionForInstance(inst);
			double weight = inst.weight();
			// double diff = 1.0d - dist[(int) actualClass]; // this works because p[0,1] =
			// dist[0,1]
			double diff = actualClass - dist[1]; // sign doesn't matter bc you square later
			// if this were not binary, you'd have to evaluate each of many classes
			// here, dist[0,1] are probabilities p0,p1 of classes 0,1
			// so:
			// if actualClass ac = 0: diff = 1 - p0 = 1 - dist[ac=0] = 1 - (1 - p1) =
			// -((ac=0) - p1)
			// if actualClass ac = 1: diff = 1 - p1 = 1 - dist[ac=1] = (ac=1) - p1
			double sqErr = weight * diff * diff;
			sumSqErr += sqErr;
		}

		// divide by sum of weights for mean
		// if all weights are 1, it's the same as numInstances

		return Math.sqrt(sumSqErr) / data.sumOfWeights();
	}

	/**
	 * Buildclassifier selects a classifier from the set of classifiers by
	 * minimising error on the training data.
	 *
	 * @param data the training data to be used for generating the boosted
	 *             classifier.
	 * @throws Exception if the classifier could not be built successfully
	 */
	public void buildClassifier(Instances data) throws Exception {

		// can classifier handle the data?
		getCapabilities().testWithFail(data);

		// remove instances with missing class
		Instances newData = new Instances(data);
		newData.deleteWithMissingClass();

		Random random = new Random(m_Seed);
		newData.randomize(random);

		int numInstances = newData.numInstances();
		double weightSum = numInstances; // for normalization
		Classifier[] classifiers = getClassifiers();
		// Evaluation eval;
		double[] weights = new double[numInstances];

		// fill weights with weights from original data
		for (int i = 0; i < weights.length; i++) {
			weights[i] = newData.get(i).weight();
		}

		// Evaluation eval = new Evaluation(newData);

		double classWeightSum = 0.0d;
		for (Classifier classifier : classifiers) {

			// normalize the weights and weight the instances
			for (int i = 0; i < newData.numInstances(); i++) {
				weights[i] /= weightSum;
				weights[i] *= 50 * classifiers.length; // should be at least 2 for two classes, etc
				if (classifier instanceof weka.core.WeightedInstancesHandler) {
					newData.get(i).setWeight(weights[i]);
				}
				;
			}

			classifier.buildClassifier(newData);

			double err = calculateMSE(classifier, newData);
			// eval.evaluateModel(classifier, newData);
			// double err = eval.pctCorrect() / 100.0d;

			/*
			 * eval.evaluateModel(classifier, newData); // this should call
			 * updateNumericScores double err = eval.errorRate(); // because you called
			 * evaluateModel, this should be calculable
			 * 
			 * change err into get the Sum Squared err originally error rate is calculated
			 * in the Evaluation.updateNumericScores loop: sumSqrErr += diff * diff;
			 * m_SumSqrErr += weight * sumSqrErr / m_NumClasses and then finally returned in
			 * the Evaluation.errorRate method return Math.sqrt(m_SumSqrErr / (m_WithClass -
			 * m_Unclassified));
			 * 
			 * to recover the sumSqrErr, square it and un-normalize ... err *= err *
			 * (eval.numInstances() - eval.unclassified()) * newData.numClasses();
			 */

			double classWeight = (1.0d / classifiers.length) * Math.log((1.0 - err) / err);
			// double classWeight = (1.0d / classifiers.length) * err; //if err is just ROC
			// area

			classWeightSum += classWeight;
			m_WeightsClassifiers.add(classWeight);

			weightSum = 0.0d;
			for (int i = 0; i < newData.numInstances(); i++) {
				Instance inst = newData.get(i);
				double actualClass = inst.classValue(); // should be 0 or 1
				double[] dist = classifier.distributionForInstance(inst);
				double diff = dist[1] - actualClass;
				// double diff = 1.0d - dist[(int)actualClass];
				weights[i] = weights[i] * Math.exp(classWeight * (diff * diff));
				weightSum += weights[i]; // will be used to normalize at beginning of next loop over classifiers
			}

		}

		// normalize the class weights
		for (int i = 0; i < m_WeightsClassifiers.size(); i++) {
			m_WeightsClassifiers.set(i, m_WeightsClassifiers.get(i) / classWeightSum);
		}

		// m_SpoofClassifier.buildClassifier(newData);

//    if (newData.classAttribute().isNominal()) {
//      newData.stratify(m_NumFolds);
//    }

		// Create meta level
//    generateMetaLevel(newData, random);

		// restart the executor pool because at the end of processing
		// a set of classifiers it gets shutdown to prevent the program
		// executing as a server
//    super.buildClassifier(newData);

		// Rebuild all the base classifiers on the full training data
//    buildClassifiers(newData);
	}

//  /**
//   * Generates the meta data
//   * 
//   * @param newData the data to work on
//   * @param random the random number generator to use for cross-validation
//   * @throws Exception if generation fails
//   */
//  protected void generateMetaLevel(Instances newData, Random random) 
//    throws Exception {
//
//    Instances metaData = metaFormat(newData);
//    m_MetaFormat = new Instances(metaData, 0);
//    for (int j = 0; j < m_NumFolds; j++) {
//      Instances train = newData.trainCV(m_NumFolds, j, random);
//      
//      // start the executor pool (if necessary)
//      // has to be done after each set of classifiers as the
//      // executor pool gets shut down in order to prevent the
//      // program executing as a server (and not returning to
//      // the command prompt when run from the command line
//      super.buildClassifier(train);
//      
//      // construct the actual classifiers
//      buildClassifiers(train);
//      
//      // Classify test instances and add to meta data
//      Instances test = newData.testCV(m_NumFolds, j);
//      for (int i = 0; i < test.numInstances(); i++) {
//	metaData.add(metaInstance(test.instance(i)));
//      }
//    }
//
//    m_MetaClassifier.buildClassifier(metaData);    
//  }

	/**
	 * Returns class probabilities.
	 *
	 * @param instance the instance to be classified
	 * @return the distribution
	 * @throws Exception if instance could not be classified successfully
	 */
	public double[] distributionForInstance(Instance instance) throws Exception {

		Classifier[] classifiers = getClassifiers();

		double[] dist = { 0.0d, 0.0d }; // should be binary, so only two class probabilities

		for (int i = 0; i < classifiers.length; i++) {
			double[] dist_i = classifiers[i].distributionForInstance(instance);
			dist[0] += dist_i[0] * m_WeightsClassifiers.get(i);
			dist[1] += dist_i[1] * m_WeightsClassifiers.get(i);
		}

		return dist;

		// return m_SpoofClassifier.distributionForInstance(instance);
		// return m_MetaClassifier.distributionForInstance(metaInstance(instance));
	}

	/**
	 * Output a representation of this classifier
	 * 
	 * @return a string representation of the classifier
	 */
	public String toString() {

		if (m_Classifiers.length == 0) {
			return "UltraBoost: No base schemes entered.";
		}
//    if (m_MetaClassifier == null) {
//      return "Stacking: No meta scheme selected.";
//    }
//    if (m_MetaFormat == null) {
//      return "Stacking: No model built yet.";
//    }
		String result = "UltraBoost\n\nBase classifiers\n\n";
		for (int i = 0; i < m_Classifiers.length; i++) {
			result += getClassifier(i).toString() + "\n\n";
		}

//    result += "\n\nMeta classifier\n\n";
//    result += m_MetaClassifier.toString();

		return result;
	}

//  /**
//   * Makes the format for the level-1 data.
//   *
//   * @param instances the level-0 format
//   * @return the format for the meta data
//   * @throws Exception if the format generation fails
//   */
//  protected Instances metaFormat(Instances instances) throws Exception {
//    ArrayList<Attribute> attributes = new ArrayList<Attribute>();
//    Instances metaFormat;
//
//    for (int k = 0; k < m_Classifiers.length; k++) {
//      Classifier classifier = (Classifier) getClassifier(k);
//      String name = classifier.getClass().getName() + "-" + (k+1);
//      if (m_BaseFormat.classAttribute().isNumeric()) {
//	attributes.add(new Attribute(name));
//      } else {
//	for (int j = 0; j < m_BaseFormat.classAttribute().numValues(); j++) {
//	  attributes.add(
//	      new Attribute(
//		  name + ":" + m_BaseFormat.classAttribute().value(j)));
//	}
//      }
//    }
//    attributes.add((Attribute) m_BaseFormat.classAttribute().copy());
//    metaFormat = new Instances("Meta format", attributes, 0);
//    metaFormat.setClassIndex(metaFormat.numAttributes() - 1);
//    return metaFormat;
//  }

	/**
	 * Makes a level-1 instance from the given instance.
	 * 
	 * @param instance the instance to be transformed
	 * @return the level-1 instance
	 * @throws Exception if the instance generation fails
	 */
//  protected Instance metaInstance(Instance instance) throws Exception {
//
//    double[] values = new double[m_MetaFormat.numAttributes()];
//    Instance metaInstance;
//    int i = 0;
//    for (int k = 0; k < m_Classifiers.length; k++) {
//      Classifier classifier = getClassifier(k);
//      if (m_BaseFormat.classAttribute().isNumeric()) {
//	values[i++] = classifier.classifyInstance(instance);
//      } else {
//	double[] dist = classifier.distributionForInstance(instance);
//	for (int j = 0; j < dist.length; j++) {
//	  values[i++] = dist[j];
//	}
//      }
//    }
//    values[i] = instance.classValue();
//    metaInstance = new DenseInstance(1, values);
//    metaInstance.setDataset(m_MetaFormat);
//    return metaInstance;
//  }

//	@Override
//	public void preExecution() throws Exception {
//		super.preExecution();
//
//    if (getMetaClassifier() instanceof CommandlineRunnable) {
//      ((CommandlineRunnable) getMetaClassifier()).preExecution();
//	}

//
//  @Override
//  public void postExecution() throws Exception {
//    super.postExecution();
//    if (getMetaClassifier() instanceof CommandlineRunnable) {
//      ((CommandlineRunnable) getMetaClassifier()).postExecution();
//    }
//  }

	/**
	 * Returns the revision string.
	 * 
	 * @return the revision
	 */
	public String getRevision() {
		return RevisionUtils.extract("$Revision: 121219 $"); // 121219
	}

	/**
	 * Main method for testing this class.
	 *
	 * @param argv should contain the following arguments: -t training file [-T test
	 *             file] [-c class index]
	 * @throws Exception
	 */
	public static void main(String[] argv) throws Exception {
		runClassifier(new UltraBoost(), argv);
	}
}
